package com.doceestereo.radioboss12;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import org.json.JSONArray;
import org.json.JSONObject;

public class MusicPlaybackService extends Service {
    public static final String ACTION_PLAY="com.doceestereo.radioboss12.PLAY_MUSIC";
    public static final String ACTION_STOP="com.doceestereo.radioboss12.STOP_MUSIC";
    public static final String ACTION_VOLUME="com.doceestereo.radioboss12.MUSIC_VOLUME";
    private static final String CHANNEL="radioboss12_music";
    private MediaPlayer player;
    private JSONArray queue=new JSONArray();
    private int currentIndex=0;
    private float volume=0.75f;
    private PowerManager.WakeLock wakeLock;
    private boolean stoppedByUser=false;

    @Override public void onCreate(){super.onCreate();createChannel();PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"RadioBoss12:MusicPlayback");}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        String action=intent.getAction();
        if(ACTION_STOP.equals(action)){stoppedByUser=true;stopPlayer();stopForeground(true);stopSelf();return START_NOT_STICKY;}
        if(ACTION_VOLUME.equals(action)){volume=intent.getFloatExtra("volume",volume);if(player!=null)try{player.setVolume(volume,volume);}catch(Exception ignored){}return START_STICKY;}
        if(ACTION_PLAY.equals(action)){
            stoppedByUser=false;
            String raw=intent.getStringExtra("queue");if(raw!=null)try{queue=new JSONArray(raw);}catch(Exception ignored){}
            currentIndex=intent.getIntExtra("index",0);volume=intent.getFloatExtra("volume",0.75f);
            startForeground(1,notification("Preparando música…"));
            if(!wakeLock.isHeld())try{wakeLock.acquire();}catch(Exception ignored){}
            playCurrent();
            return START_STICKY;
        }
        return START_NOT_STICKY;
    }
    private void playCurrent(){
        stopPlayer();
        if(currentIndex<0||currentIndex>=queue.length()){stopForeground(true);stopSelf();return;}
        try{
            JSONObject item=queue.getJSONObject(currentIndex);Uri uri=Uri.parse(item.getString("uri"));
            String name=item.optString("name","RadioBoss12");
            player=new MediaPlayer();player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);player.setDataSource(this,uri);player.setVolume(volume,volume);
            player.setOnPreparedListener(mp->{if(player==mp){startForeground(1,notification(name));mp.start();}});
            player.setOnCompletionListener(mp->{if(player==mp){currentIndex++;playCurrent();}});
            player.setOnErrorListener((mp,what,extra)->{if(player==mp){currentIndex++;playCurrent();}return true;});
            player.prepareAsync();
        }catch(Exception e){currentIndex++;if(currentIndex<queue.length())playCurrent();else{stopForeground(true);stopSelf();}}
    }
    private void stopPlayer(){if(player!=null){try{player.setOnCompletionListener(null);player.setOnErrorListener(null);player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}}
    private Notification notification(String title){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("RadioBoss12 · 12 Estéreo").setContentText(title).setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).build();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"RadioBoss12 música",NotificationManager.IMPORTANCE_LOW);c.setDescription("Mantiene la música reproduciéndose en segundo plano");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    @Override public void onDestroy(){stopPlayer();if(wakeLock!=null&&wakeLock.isHeld())try{wakeLock.release();}catch(Exception ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
