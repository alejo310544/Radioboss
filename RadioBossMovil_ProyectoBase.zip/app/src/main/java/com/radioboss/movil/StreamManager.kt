package com.radioboss.movil

import java.io.OutputStream
import java.net.Socket
import kotlin.concurrent.thread

class StreamManager {
    private var socket: Socket? = null
    private var outputStream: OutputStream? = null

    fun conectarServidor(ip: String, puerto: Int, contrasena: String, alConectar: () -> Unit, alFallar: (Exception) -> Unit) {
        thread {
            try {
                socket = Socket(ip, puerto)
                outputStream = socket?.getOutputStream()

                val authString = "password=$contrasena\r\n"
                outputStream?.write(authString.toByteArray())
                outputStream?.flush()

                alConectar()
            } catch (e: Exception) {
                alFallar(e)
            }
        }
    }

    fun enviarBytesDeAudio(buffer: ByteArray, size: Int) {
        try {
            if (socket?.isConnected == true) {
                outputStream?.write(buffer, 0, size)
            }
        } catch (e: Exception) { }
    }

    fun desconectar() {
        outputStream?.close()
        socket?.close()
    }
}
