package com.radioboss.movil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RadioBossScreen()
        }
    }
}

@Composable
fun RadioBossScreen() {
    Text(text = "Radio Boss Móvil - Consola de Transmisión")
}
