package com.radioboss.movil

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import android.net.Uri

class BotoneraManager(private val context: Context) {
    private var soundPool: SoundPool

    init {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        
        soundPool = SoundPool.Builder()
            .setMaxStreams(5)
            .setAudioAttributes(audioAttributes)
            .build()
    }

    fun cargarEfectoDesdeUri(uri: Uri): Int {
        return context.contentResolver.openFileDescriptor(uri, "r")?.use {
            soundPool.load(it.fileDescriptor, 0, it.statSize, 1)
        } ?: -1
    }

    fun reproducirEfecto(soundId: Int) {
        if (soundId != -1) {
            soundPool.play(soundId, 1.0f, 1.0f, 1, 0, 1.0f)
        }
    }
}
