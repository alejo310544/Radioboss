RadioBos1 - programacion de tandas M3U

Novedades de esta version:
- En Publicidad se puede abrir una lista M3U completa como una tanda.
- La tanda conserva el orden de las pistas y se reproduce automaticamente una tras otra.
- Cada tanda permite marcar varias horas del dia y elegir un minuto comun (por ejemplo, 07:50, 09:50 y 11:50).
- Dos tandas pueden alternarse marcando horas distintas en cada una (por ejemplo, Tanda 1 a las horas impares y Tanda 2 a las pares).
- Las listas y horarios se guardan en la sesion local.

Uso:
1. En Cabina/Musica, crea tu lista y usa Guardar M3U.
2. Abre Publicidad > Abrir lista M3U y selecciona ese archivo.
3. Marca las horas para esa tanda, escribe el minuto y pulsa Guardar horario.
4. Usa Probar tanda para verificar la reproduccion completa.

Nota: el programador se ejecuta mientras RadioBos1 permanece abierto en el telefono. Android puede restringir procesos en segundo plano por bateria. La lista M3U debe contener URI de audio accesibles en el telefono; las rutas de Windows como C:\Musica\anuncio.mp3 no funcionan directamente en Android.

NOVEDAD VERSION 1.3 - JINGLES AUTOMATICOS
- Nueva sección Jingles en la navegación.
- Cargar un archivo de audio directamente desde el almacenamiento del teléfono mediante el selector de Android.
- Intervalos configurables de 1, 2, 3, 4, 5, 6, 10, 15, 20, 30, 45 o 60 minutos.
- Activar/desactivar la repetición automática sin borrar el archivo ni su configuración.
- Volumen independiente para el jingle y botón para probarlo.
- El archivo, intervalo, volumen y estado se guardan en el teléfono.
- La comprobación automática se ejecuta mientras la actividad principal está en funcionamiento; Android puede limitarla si cierra la app.


NOVEDAD - PRIORIDAD DE PUBLICIDAD SOBRE MUSICA
- Al comenzar una tanda M3U programada o al probarla, se pausa el canal musical principal.
- Los anuncios de la tanda se reproducen consecutivamente sin que la música se mezcle con ellos.
- Cuando termina toda la tanda, la playlist musical continúa automáticamente desde el punto donde quedó pausada.
- Los efectos de la botonera y los jingles conservan sus reproductores independientes y no activan esta pausa.
- Los anuncios individuales con horario también pausan la música y la reanudan al terminar.
