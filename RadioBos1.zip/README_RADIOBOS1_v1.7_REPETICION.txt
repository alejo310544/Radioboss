RadioBos1 Neon v1.7 - Controles de repeticion y limpieza de playlist

Cambios incluidos:
- Boton "↻ Lista": activa/desactiva repetir la playlist completa en modo secuencial.
- Boton "🔂 Canción": activa/desactiva repetir la canción actual. El botón Siguiente sigue avanzando manualmente.
- Los modos de repetición son mutuamente excluyentes.
- La preferencia de repetición se guarda en la sesión.
- Botón "Limpiar" en el encabezado de la playlist, con confirmación. Detiene la reproducción y elimina las pistas de la lista de RadioBos1, pero NO borra los archivos de audio del teléfono.
- Se conserva la reproducción aleatoria existente. En modo aleatorio, el servicio sigue recorriendo las pistas al azar como en la versión anterior.

Compilación:
El proyecto usa Android Gradle Plugin y Java 17. En GitHub Actions, sube el contenido de este ZIP al repositorio y ejecuta el workflow de compilación (Build RadioBoss 12 APK).

Nota de pruebas:
Los cambios de código se revisaron y el ZIP se valida como archivo, pero no se pudo ejecutar una compilación Android ni probar el APK en un dispositivo desde este entorno. Comprueba el APK antes de sustituir la instalación que ya funciona.
