RADIOBOS1 / RADIOBOSS12 - VERSION 1.4 NEON

CAMBIOS INTEGRADOS EN EL PROYECTO
- Cabina musical rediseñada con una tarjeta oscura y acentos neón turquesa.
- Controles compactos de anterior, reproducir/pausar, siguiente y aleatorio.
- Barra de avance con tiempo transcurrido y duración total; permite buscar otra posición de la canción.
- Control de volumen más compacto.
- Botones de añadir música, importar/exportar M3U y detener en formato reducido.
- Reproducción aleatoria implementada en el servicio: el botón cambia el estado real del servicio y la cola elige pistas sin repetir hasta completar el ciclo.
- Acciones de anterior/siguiente y pausa/reanudación en el servicio de música.
- El estado y el avance del reproductor se actualizan en la interfaz.
- Tarjetas y controles generales más compactos; sección de tandas de publicidad con acentos ámbar.
- Se mantiene la pausa de la música durante la publicidad y la reanudación al terminar la tanda.

COMPILACIÓN
Este ZIP contiene el código fuente Android/Gradle, no un APK ya compilado. En el repositorio, ejecuta el workflow de GitHub Actions existente para generar el APK. La compilación y prueba física en dispositivo no se pudieron ejecutar en este entorno; valida el APK generado antes de usarlo en directo.


IMPORTACIÓN MULTIPLE Y POR CARPETA (actualización)
- El botón + Añadir ahora permite seleccionar varias canciones en una sola operación.
- También permite elegir una carpeta completa; busca audios compatibles dentro de subcarpetas.
- Evita añadir duplicados al mismo listado y conserva las pistas ya importadas.
- El acceso a archivos utiliza el selector de documentos de Android y permisos persistentes.
