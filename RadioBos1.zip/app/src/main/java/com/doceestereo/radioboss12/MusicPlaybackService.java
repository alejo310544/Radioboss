package com.doceestereo.radioboss12;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Random;

public class MusicPlaybackService extends Service {
    public static final String ACTION_PLAY="com.doceestereo.radioboss12.PLAY_MUSIC";
    public static final String ACTION_STOP="com.doceestereo.radioboss12.STOP_MUSIC";
    public static final String ACTION_VOLUME="com.doceestereo.radioboss12.MUSIC_VOLUME";
    public static final String ACTION_PAUSE_FOR_AD="com.doceestereo.radioboss12.PAUSE_MUSIC_FOR_AD";
    public static final String ACTION_RESUME_AFTER_AD="com.doceestereo.radioboss12.RESUME_MUSIC_AFTER_AD";
    public static final String ACTION_SHUFFLE="com.doceestereo.radioboss12.SET_SHUFFLE";
    public static final String ACTION_TOGGLE="com.doceestereo.radioboss12.TOGGLE_MUSIC";
    public static final String ACTION_NEXT="com.doceestereo.radioboss12.NEXT_MUSIC";
    public static final String ACTION_PREVIOUS="com.doceestereo.radioboss12.PREVIOUS_MUSIC";
    public static final String ACTION_SEEK="com.doceestereo.radioboss12.SEEK_MUSIC";
    public static final String ACTION_REPEAT_MODE="com.doceestereo.radioboss12.REPEAT_MODE";
    public static final String ACTION_STATE="com.doceestereo.radioboss12.MUSIC_STATE";
    public static final String EXTRA_STATE="com.doceestereo.radioboss12.MUSIC_STATE_DATA";
    private static final String CHANNEL="radioboss12_music";
    private MediaPlayer player;
    private JSONArray queue=new JSONArray();
    private int currentIndex=0;
    private float volume=0.75f;
    private PowerManager.WakeLock wakeLock;
    private boolean pausedForAd=false, userPaused=false, playerPrepared=false, shuffleEnabled=false;
    // 0 = sin repetición de lista; 1 = repetir playlist; 2 = repetir la canción actual.
    private int repeatMode=0;
    private final ArrayList<Integer> playedIndices=new ArrayList<>();
    private final ArrayList<Integer> history=new ArrayList<>();
    private int historyCursor=0;
    private final Random random=new Random();
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final Runnable ticker=new Runnable(){@Override public void run(){broadcastState();handler.postDelayed(this,500);}};

    @Override public void onCreate(){super.onCreate();createChannel();PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"RadioBoss12:MusicPlayback");handler.post(ticker);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null)return START_NOT_STICKY;
        String action=intent.getAction();
        if(ACTION_STOP.equals(action)){userPaused=false;pausedForAd=false;playerPrepared=false;stopPlayer();stopForeground(true);broadcastState();stopSelf();return START_NOT_STICKY;}
        if(ACTION_PAUSE_FOR_AD.equals(action)){if(player!=null){pausedForAd=true;try{if(player.isPlaying())player.pause();}catch(Exception ignored){}}broadcastState();return START_NOT_STICKY;}
        if(ACTION_RESUME_AFTER_AD.equals(action)){if(pausedForAd){pausedForAd=false;if(player!=null&&playerPrepared&&!userPaused)try{player.start();}catch(Exception ignored){}}broadcastState();return START_NOT_STICKY;}
        if(ACTION_VOLUME.equals(action)){volume=intent.getFloatExtra("volume",volume);if(player!=null)try{player.setVolume(volume,volume);}catch(Exception ignored){}return START_STICKY;}
        if(ACTION_SHUFFLE.equals(action)){boolean enabled=intent.getBooleanExtra("shuffle",shuffleEnabled);if(enabled!=shuffleEnabled){shuffleEnabled=enabled;playedIndices.clear();if(shuffleEnabled&&currentIndex>=0&&currentIndex<queue.length())playedIndices.add(currentIndex);}broadcastState();return START_NOT_STICKY;}
        if(ACTION_TOGGLE.equals(action)){if(player!=null&&playerPrepared){try{if(player.isPlaying()){player.pause();userPaused=true;}else{userPaused=false;if(!pausedForAd)player.start();}}catch(Exception ignored){}}broadcastState();return START_NOT_STICKY;}
        if(ACTION_NEXT.equals(action)){if(queue.length()>0){advanceQueue();userPaused=false;playCurrent();}return START_NOT_STICKY;}
        if(ACTION_PREVIOUS.equals(action)){if(queue.length()>0){if(shuffleEnabled&&historyCursor>0){historyCursor--;currentIndex=history.get(historyCursor);}else currentIndex=Math.max(0,currentIndex-1);userPaused=false;playCurrent();}return START_NOT_STICKY;}
        if(ACTION_SEEK.equals(action)){if(player!=null&&playerPrepared){try{player.seekTo(Math.max(0,intent.getIntExtra("position",0)));}catch(Exception ignored){}}broadcastState();return START_NOT_STICKY;}
        if(ACTION_REPEAT_MODE.equals(action)){repeatMode=Math.max(0,Math.min(2,intent.getIntExtra("repeatMode",0)));broadcastState();return START_NOT_STICKY;}
        if(ACTION_PLAY.equals(action)){
            userPaused=false;pausedForAd=false;playerPrepared=false;
            String raw=intent.getStringExtra("queue");if(raw!=null)try{queue=new JSONArray(raw);}catch(Exception ignored){}
            currentIndex=intent.getIntExtra("index",0);volume=intent.getFloatExtra("volume",0.75f);shuffleEnabled=intent.getBooleanExtra("shuffle",false);repeatMode=Math.max(0,Math.min(2,intent.getIntExtra("repeatMode",repeatMode)));playedIndices.clear();history.clear();historyCursor=0;
            if(currentIndex>=0&&currentIndex<queue.length()){history.add(currentIndex);historyCursor=0;if(shuffleEnabled)playedIndices.add(currentIndex);}
            startForeground(1,notification("Preparando música…"));if(!wakeLock.isHeld())try{wakeLock.acquire();}catch(Exception ignored){}playCurrent();return START_STICKY;
        }
        return START_NOT_STICKY;
    }
    private void playCurrent(){
        stopPlayer();playerPrepared=false;
        if(currentIndex<0||currentIndex>=queue.length()){broadcastState();return;}
        try{JSONObject item=queue.getJSONObject(currentIndex);Uri uri=Uri.parse(item.getString("uri"));String name=item.optString("name","RadioBoss12");
            player=new MediaPlayer();player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());player.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);player.setDataSource(this,uri);player.setVolume(volume,volume);
            player.setOnPreparedListener(mp->{if(player==mp){playerPrepared=true;startForeground(1,notification(name));if(!pausedForAd&&!userPaused)mp.start();broadcastState();}});
            player.setOnCompletionListener(mp->{if(player==mp){if(repeatMode==2){playCurrent();return;}advanceQueue();playCurrent();}});
            player.setOnErrorListener((mp,what,extra)->{if(player==mp){advanceQueue();playCurrent();}return true;});player.prepareAsync();broadcastState();
        }catch(Exception e){advanceQueue();if(currentIndex<queue.length())playCurrent();else broadcastState();}
    }
    private void advanceQueue(){
        if(!shuffleEnabled){currentIndex++;if(currentIndex>=queue.length()&&repeatMode==1&&queue.length()>0)currentIndex=0;if(currentIndex>=0&&currentIndex<queue.length()){if(historyCursor<history.size()-1){while(history.size()>historyCursor+1)history.remove(history.size()-1);}history.add(currentIndex);historyCursor=history.size()-1;}return;}
        int n=queue.length();if(n<=1){currentIndex=n;return;}if(playedIndices.size()>=n){playedIndices.clear();playedIndices.add(currentIndex);}ArrayList<Integer> candidates=new ArrayList<>();for(int i=0;i<n;i++)if(!playedIndices.contains(i))candidates.add(i);if(candidates.isEmpty()){currentIndex=n;return;}currentIndex=candidates.get(random.nextInt(candidates.size()));playedIndices.add(currentIndex);if(historyCursor<history.size()-1)while(history.size()>historyCursor+1)history.remove(history.size()-1);history.add(currentIndex);historyCursor=history.size()-1;
    }
    private void broadcastState(){Intent i=new Intent(ACTION_STATE);i.setPackage(getPackageName());i.putExtra("playing",player!=null&&playerPrepared&&player.isPlaying());i.putExtra("prepared",playerPrepared);i.putExtra("hasTrack",player!=null);i.putExtra("paused",userPaused||pausedForAd);i.putExtra("index",currentIndex);i.putExtra("shuffle",shuffleEnabled);i.putExtra("repeatMode",repeatMode);int pos=0,dur=0;String name="Sin reproducción";try{if(player!=null&&playerPrepared){pos=player.getCurrentPosition();dur=player.getDuration();}}catch(Exception ignored){}try{if(currentIndex>=0&&currentIndex<queue.length())name=queue.getJSONObject(currentIndex).optString("name","Pista musical");}catch(Exception ignored){}i.putExtra("position",pos);i.putExtra("duration",dur);i.putExtra("name",name);i.putExtra("paused",userPaused||pausedForAd);sendBroadcast(i);}
    private void stopPlayer(){playerPrepared=false;if(player!=null){try{player.setOnCompletionListener(null);player.setOnErrorListener(null);player.stop();}catch(Exception ignored){}try{player.release();}catch(Exception ignored){}player=null;}}
    private Notification notification(String title){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,1,open,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);return b.setSmallIcon(android.R.drawable.ic_media_play).setContentTitle("RadioBoss12 · 12 Estéreo").setContentText(title).setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).build();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"RadioBoss12 música",NotificationManager.IMPORTANCE_LOW);c.setDescription("Mantiene la música reproduciéndose en segundo plano");((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}}
    @Override public void onDestroy(){handler.removeCallbacks(ticker);stopPlayer();if(wakeLock!=null&&wakeLock.isHeld())try{wakeLock.release();}catch(Exception ignored){}super.onDestroy();}
    @Override public IBinder onBind(Intent intent){return null;}
}
